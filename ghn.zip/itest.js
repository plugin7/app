t.prototype.endGame = function(e) {
                
                
            }
            ,
